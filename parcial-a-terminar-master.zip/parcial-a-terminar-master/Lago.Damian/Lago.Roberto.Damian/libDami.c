#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libDami.h"
#define totalUsuario 5
#define totalProducto 10
void inicializarUsuarios(eUsuario usuarios[], int sizeU)
{
    int idUsuario[]={1,2,3,4,5};
    char idNombre[][51]= {"Geronimo","Adalberto","Inocencia","Felipe","Lucrecia",};
    char idpassword[][51]= {"fgz865","dcb215","Inocencia13","Felipe1090","lamascapaLucrecia",};
    int idProducto[]= {100,101,102,103,104,105,106,107,108,109};
    int i;

    for(i=0; i<sizeU; i++)
    {
        usuarios[i].idUsuario=idUsuario[i];
        strcpy(usuarios[i].nombreCuenta,idNombre[i]);
        strcpy(usuarios[i].password,idpassword[i]);
        usuarios[i].idProducto=idProducto[i];
    }
}
 void inicializarProductos(eProducto productos[], int sizeP)
 {
     int idProducto[]= {100,101,102,103,104,105,106,107,108,109};
     char descripcion[][51]={"mouse","teclado","cooler","gabinete","pad","memorias","pilas","fundas","tablet","celulares"};
     float precio[]={139,150,49,250,15,350,9,550,1500,2000};
     int stock[]={15,15,5,9,30,12,44,4,2,6};
     int i;
     for(i=0;i<sizeP;i++)
     {
         productos[i].idProducto=idProducto[i];
         strcpy(productos[i].descripcion,descripcion[i]);
         productos[i].precio=precio[i];
         productos[i].stock=stock[i];
     }

 }

void inicializarEstado(eUsuario usuarios[],int tam,int valor)
{
    int i;
    for(i=0;i<tam;i++)
    {
        usuarios[i].estadoUsuario=valor;
    }
}


int ingresarInt(char preg[])
{
    int aux;
    printf("%s",preg);
    scanf("%d",&aux);
    return aux;
}

float ingresarFloat(char preg[])
{
    float aux;
    printf("%s",preg);
    scanf("%f",&aux);
    return aux;
}

char ingresarChar(char preg[])
{
    char aux;
    printf("%s",preg);
    fflush(stdin);
    scanf("%c",&aux);
    return aux;
}

int validarNumero(char lista[])
{
   int i=0;
   while(lista[i] != '\0')
   {
       if(lista[i] < '0' || lista[i] > '9')
           {
               return 0;
           }

       i++;
   }
   return 1;
}

int validarAlfaNumerico(char lista[])
{
   int i=0;
   while(lista[i] != '\0')
   {
       if((lista[i] != ' ') && (lista[i] < 'a' || lista[i] > 'z') && (lista[i] < 'A' || lista[i] > 'Z') && (lista[i] < '0' || lista[i] > '9'))
           {
               return 0;
           }

       i++;
   }
   return 1;
}

int validarLetras(char lista[])
{
   int i=0;
   while(lista[i] != '\0')
   {
       if((lista[i] != ' ') && (lista[i] < 'a' || lista[i] > 'z') && (lista[i] < 'A' || lista[i] > 'Z'))
           {
               return 0;
           }

       i++;
   }
   return 1;
}

int validarNumeroFloat(char lista[])
{
   int i=0;
   int cantidadPuntos=0;
   while(lista[i] != '\0')
   {
       if (lista[i] == '.' && cantidadPuntos == 0)
       {
           cantidadPuntos++;
           i++;
           continue;

       }
       if(lista[i] < '0' || lista[i] > '9')
           {
               return 0;
           }

       i++;
   }
   return 1;
}

void ingresarResp(char preg[],char resp[])
{
    printf("%s",preg);
    scanf ("%s", resp);
}

int ingresarRespLetras(char preg[],char resp[])
{
    char aux[250];
    ingresarResp(preg,aux);
    if(validarLetras(aux))
    {
        strcpy(resp,aux);
        return 1;
    }
    return 0;
}



int ingresarRespNumeros(char preg[],char resp[])
{
    char aux[250];
    ingresarResp(preg,aux);
    if(validarNumero(aux))
    {
        strcpy(resp,aux);
        return 1;
    }
    return 0;
}


int ingresarRespNumeroFloat(char preg[],char resp[])
{
    char aux[250];
    ingresarResp(preg,aux);
    if(validarNumeroFloat(aux))
    {
        strcpy(resp,aux);
        return 1;
    }
    return 0;
}
int ingresarRespAlfanumerica(char preg[],char resp[])
{
    char aux[250];
    ingresarResp(preg,aux);
        if(validarAlfaNumerico(aux))
        {
            strcpy(resp,aux);
                return 1;
        }
        return 0;
}
int buscarLugar(eUsuario usuarios[],int tam)
{
    int i;
    for(i=0;i < tam; i++)
    {
        if(usuarios[i].estadoUsuario == 0)
        {
            return i;
        }
    }
    return -1;
}

int crearPublicacion(eProducto productos[], int tamP, int ultimaPublicacion, eUsuario usuario[] , int tamU )
{
    int hayLugar;
    int motivo;
    int idUsuario;
    int idUsuarioAux;
    char nombreCuenta[51];
    char nombreCuentaAux[51];
    char auxDescripcionProducto[51];
    char descripcionProducto[51];
    char auxPrecio;
    float precio;
    int auxStock;
    int stock;
    int idProducto;

    hayLugar = buscarLugar(productos, tamP);
    if(hayLugar!=-1)
    {
        strcpy(nombreCuenta,ingresarRespAlfanumerica("ingrese nombre de cuenta: ",nombreCuentaAux));

        idProducto = buscarProductoxUsuario(productos,tamP,idUsuario);

        if(idProducto!=-1)
        {
                if (!ingresarRespNumeroFloat("ingrese precio del producto: \n",auxPrecio))
                {
                    printf ("el precio solo deben ser numeros\n");

                }
                precio = atof(auxPrecio);

            if (!ingresarRespNumeros("ingrese stock del producto: \n",auxStock))
                {
                    printf ("el stock solo deben ser numeros\n");

                }
            stock = atoi(auxStock);
             if(!ingresarRespAlfanumerica("ingrese descripcion del producto: \n",auxDescripcionProducto))
             {
                 printf("la descripcion debe tener letras o numeros unicamente");

             }

            strcpy(productos[hayLugar].descripcion,auxDescripcionProducto);
            productos[hayLugar].stock=auxStock;
            productos[hayLugar].precio=auxPrecio;


        }
        else
        {
            printf("Usuario no existe!!\n");
        }

    }
    else
    {
        printf("No hay lugar para ams publicaciones!!!\n");
    }

    return hayLugar;
}

int buscarProductoxUsuario(eProducto productos[],int tamP,eUsuario usuarios[])
{
    int i;
    int idusuario = -1;
    for(i=0; i<tamP; i++)
    {
        if(usuarios[i].idProducto == productos[i].idProducto)
        {
            idusuario = usuarios[i].idUsuario;
            break;
        }
    }
    return idusuario;
}


